#pragma once
#include "enemy.h"
class minion : public enemy
{
public:
	minion();
	~minion();
};

