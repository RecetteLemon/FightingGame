#pragma once
#include "ship.h"

class battle2 : public ship
{
public:
	virtual void keyControl(void);

	battle2();
	~battle2();
};

